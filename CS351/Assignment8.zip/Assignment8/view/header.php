<?php
?>

 <header>
        <img src ="./images/misc/FenderStratocasterHeader.png" alt ="Fender Stratocaster">
        <h2> The Guitar Store </h2>
        <h3> For rock stars everywhere! </h3>
 </header>
